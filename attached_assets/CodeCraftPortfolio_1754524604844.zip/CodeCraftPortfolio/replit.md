# Portfolio Website

## Overview

This is a modern, full-stack portfolio website built as a single-page application with a professional design showcasing skills, projects, and contact functionality. The application features a React frontend with shadcn/ui components, Express.js backend, and in-memory storage for development. The portfolio includes sections for hero introduction, about me, featured projects, skills showcase, and a contact form with backend persistence.

## Recent Changes (January 5, 2025)
- Built complete portfolio website with all requested sections
- Implemented responsive navigation with smooth scrolling
- Created hero section with professional introduction and call-to-action buttons
- Added about section with professional bio, headshot, and resume download
- Built projects showcase featuring 6 diverse projects with technologies and links
- Implemented skills section with categorized technical skills and visual level indicators
- Created contact form with validation and backend API integration
- Added professional footer with social media links
- Fixed CSS import order and component import path issues
- Resolved SQL schema import errors and cleaned up storage interface

## Enhanced Project Features (January 5, 2025)
- Added functional email notifications for contact form with Nodemailer integration
- Created interactive Algorithm Optimization Suite demo with sorting visualizations
- Built 3D Graphics Renderer demo showcasing OpenGL concepts and vector mathematics
- Developed Enterprise System Monitor with real-time infrastructure monitoring
- Implemented Database Administration Suite with SQL Server management capabilities
- Created Active Directory Management Console for domain services administration
- Added live project demonstrations accessible via multiple demo routes
- Enhanced all project descriptions with technical implementation details and enterprise impact
- Created comprehensive project documentation with performance metrics
- Established project template guide for adding personal user projects

## Professional Project Portfolio (January 5, 2025)
The portfolio now showcases 7 enterprise-grade projects with interactive demonstrations:
1. Enterprise System Monitor - Real-time infrastructure monitoring across 500+ servers
2. Database Administration Suite - SQL Server management with 99.9% uptime achievement  
3. 3D Graphics Renderer - Advanced OpenGL implementation with vector mathematics
4. Network Infrastructure Manager - LAN/WAN management for enterprise environments
5. Algorithm Optimization Suite - Performance analysis with interactive visualizations
6. Active Directory Management Console - Domain services for 10,000+ user management
7. IT Service Portfolio Website - Modern React/TypeScript showcase platform

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React SPA**: Built with React 18 using TypeScript for type safety
- **Component Library**: shadcn/ui components built on Radix UI primitives for accessibility and modern design
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **State Management**: TanStack Query (React Query) for server state management and API caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Express.js Server**: RESTful API with middleware for JSON parsing, CORS, and request logging
- **TypeScript**: Full TypeScript implementation for type safety across the stack
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes
- **Development Features**: Hot module replacement and development-only features for Replit environment

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for database migrations and schema management
- **Connection**: Neon Database serverless PostgreSQL for cloud deployment
- **Fallback Storage**: In-memory storage implementation for development/testing scenarios

### API Structure
- **Contact Endpoints**: 
  - POST `/api/contact` for form submissions with Zod validation
  - GET `/api/contact` for admin access to submissions
- **Resume Download**: GET `/api/resume` endpoint for resume file serving
- **Validation**: Zod schemas for request validation with detailed error messages

### Design System
- **Theme System**: CSS custom properties with light/dark mode capability
- **Typography**: Inter font family with consistent spacing and sizing
- **Color Palette**: Professional blue and neutral color scheme with semantic color tokens
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts
- **Animations**: Smooth transitions and hover effects using CSS transforms

### Content Management
- **Static Data**: Portfolio content stored in TypeScript files for type safety
- **Image Assets**: External image URLs (Unsplash) for demo content
- **Form Handling**: React Hook Form with Zod resolvers for validation

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript support
- **Build Tools**: Vite with React plugin, esbuild for production builds
- **Development Tools**: tsx for TypeScript execution, Replit-specific development plugins

### UI and Styling
- **Component Library**: Radix UI primitives (@radix-ui/react-*) for accessible components
- **Styling**: Tailwind CSS with PostCSS, Autoprefixer for vendor prefixes
- **Icons**: Lucide React for consistent iconography, React Icons for social media icons
- **Animations**: Class Variance Authority for component variants, clsx for conditional classes

### Backend and Database
- **Database**: Neon Database (@neondatabase/serverless) for PostgreSQL hosting
- **ORM**: Drizzle ORM with Drizzle Kit for schema management and migrations
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Validation**: Zod for runtime type validation and schema definition

### State Management and Data Fetching
- **Query Management**: TanStack React Query for server state, caching, and API management
- **Form Management**: React Hook Form with Hookform Resolvers for form validation
- **Date Handling**: date-fns for date manipulation and formatting

### Development and Tooling
- **TypeScript**: Full TypeScript configuration with path mapping
- **Linting and Formatting**: ESLint configuration implied through component structure
- **Component Development**: shadcn/ui CLI configuration for component generation