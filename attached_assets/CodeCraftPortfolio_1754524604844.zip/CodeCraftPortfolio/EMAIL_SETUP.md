# Email Configuration for Portfolio Contact Form

Your portfolio now has a fully functional contact form that can send email notifications. To enable email functionality, you'll need to set up the following environment variables.

## Quick Setup Options

### Option 1: Gmail (Recommended for personal use)
1. Go to your Google Account settings
2. Enable 2-factor authentication
3. Generate an "App Password" for your portfolio
4. Set these environment variables in Replit:
   - `EMAIL_USER`: your-email@gmail.com
   - `EMAIL_PASSWORD`: your-16-character-app-password

### Option 2: Professional Email Service
For production use, consider services like:
- SendGrid
- Mailgun
- Amazon SES
- Microsoft 365

## Setting Environment Variables in Replit

1. Go to your Replit project
2. Click on "Secrets" in the left sidebar (lock icon)
3. Add these secrets:
   - Key: `EMAIL_USER`, Value: your email
   - Key: `EMAIL_PASSWORD`, Value: your app password

## Current Functionality

✅ **With Email Configured:**
- Contact form submissions are stored in memory
- You receive email notifications at: evangeorgedossantos@yahoo.ca
- Visitors get automatic confirmation emails
- Professional HTML email templates

✅ **Without Email Configured:**
- Contact form submissions are still stored
- Messages are logged to console
- Form still works, just no email notifications

## Testing the Contact Form

1. Visit your portfolio website
2. Scroll to the Contact section
3. Fill out and submit the form
4. Check the server logs for confirmation
5. If email is configured, check your inbox

The contact form includes validation and error handling, so it's ready for production use!